rvmeta.CMH <- function(score.stat.vec.list,maf.vec.list,cov.mat.list,var.Y.list,N.list,alternative=c('two.sided','greater','less'),no.boot,alpha=0.05,rv.test,extra.pars=list())
  {
    if(length(alternative)>1) alternative <- "two.sided";
    res.list <- list();
    X.T.times.Y.centered.list <- list();
    X.T.times.X.list <- list();
    ## maf.vec <- rep(0,length(score.stat.vec.list[[1]]));
    ## mac.vec <- maf.vec;
    maf.vec <- extra.pars$maf.vec;
    mac.vec <- extra.pars$mac.vec;
    mac.vec.list <- extra.pars$mac.vec.list;
    X.T.times.Y <- rep(0,length(score.stat.vec.list[[1]]));
    X.T.times.X <- matrix(0,nrow=length(score.stat.vec.list[[1]]),ncol=length(score.stat.vec.list[[1]]));
    direction.burden.by.study.vec <- rep('',length(score.stat.vec.list[[1]]));
    direction.meta.single.var.vec <- rep('',length(score.stat.vec.list));
    for(ii in 1:length(score.stat.vec.list))
      {
        score.stat.vec.list[[ii]] <- rm.na(score.stat.vec.list[[ii]]);
        U.ii <- sum(score.stat.vec.list[[ii]]);

        if(U.ii>0) direction.burden.by.study.vec[ii] <- "+";
        if(U.ii<0) direction.burden.by.study.vec[ii] <- "-";
        if(U.ii==0) direction.burden.by.study.vec[ii] <- "?";        
        ## maf.vec.list[[ii]] <- rm.na(maf.vec.list[[ii]]);
        ## mac.vec.list[[ii]] <- rm.na(mac.vec.list[[ii]]);
        cov.mat.list[[ii]] <- as.matrix(rm.na(cov.mat.list[[ii]]));
        X.T.times.Y <- X.T.times.Y+(sqrt(N.list[[ii]]))*(score.stat.vec.list[[ii]])*sqrt(diag(cov.mat.list[[ii]]))*sqrt(var.Y.list[[ii]]);
        X.T.times.X <- X.T.times.X+N.list[[ii]]*(cov.mat.list[[ii]])*(var.Y.list[[ii]]);
        var.Y.list[[ii]] <- 1;
        X.T.times.X.list[[ii]] <- N.list[[ii]]*(cov.mat.list[[ii]])*(var.Y.list[[ii]]);
        X.T.times.Y.centered.list[[ii]] <- (sqrt(N.list[[ii]]))*(score.stat.vec.list[[ii]])*sqrt(diag(cov.mat.list[[ii]]))*sqrt(var.Y.list[[ii]]);
        ## maf.vec <- maf.vec.list[[ii]]*(N.list[[ii]])+maf.vec
        ## mac.vec <- mac.vec.list[[ii]]+mac.vec;
      }    
    for(ii in 1:length(X.T.times.Y))
      {
        U.ii <- X.T.times.Y[ii];
        if(U.ii>0) direction.meta.single.var.vec[ii] <- "+";
        if(U.ii<0) direction.meta.single.var.vec[ii] <- "-";
        if(U.ii==0) direction.meta.single.var.vec[ii] <- "?"; 
      }
    direction.meta.single.var <- paste(direction.meta.single.var.vec,sep='',collapse='');
    direction.burden.by.study <- paste(direction.burden.by.study.vec,sep='',collapse='');
    N <- sum(unlist(N.list));
    ##maf.vec <- maf.vec/N;
    cov.mat <- X.T.times.X/N;
    if(length(score.stat.vec.list[[1]])==1)
      {
        U.stat <- X.T.times.Y;
        V.stat.sq <- as.numeric(X.T.times.X);
        var.X <- cov.mat;
        beta1.est <- U.stat/V.stat.sq;
        beta1.sd <- 1/V.stat.sq;
        hsq.est <- beta1.est*beta1.est*var.X;        
        if(alternative=='two.sided')
          {
            statistic <- U.stat^2/V.stat.sq;
            p.value <- pchisq(statistic,df=1,lower.tail=FALSE);
          }
        if(alternative=='greater')
          {
            statistic <- U.stat/sqrt(V.stat.sq);
            p.value <- pnorm(statistic,lower.taill=FALSE);
          }
        if(alternative=='less')
          {
            statistic <- U.stat/sqrt(V.stat.sq);
            p.value <- pnorm(statistic,lower.taill=TRUE);
          }
        return(list(statistic=statistic,
                    p.value=p.value,
                    no.site=1,
                    beta1.est=beta1.est,
                    beta1.sd=beta1.sd,
                    hsq.est=hsq.est,
                    direction.meta.single.var=direction.meta.single.var,
                    direction.burden.by.study=direction.burden.by.study));
      }
    if(rv.test=='WSS')
      {
        weight <- extra.pars$weight;
        if(length(weight)!=1) weight <- 'MB';
        res <- rvmeta.CMH.wss(X.T.times.Y.centered.list,X.T.times.X.list,maf.vec,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha,weight);
      }
    if(rv.test=='VT')
      {
        ##########print('mac.vec')
        ##########print(mac.vec);
        res <- rvmeta.CMH.vt(X.T.times.Y.centered.list,X.T.times.X.list,mac.vec,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha,extra.pars=list(max.TH=extra.pars$max.TH));
      }
    if(rv.test=='SKAT')
      {
        kernel <- extra.pars$kernel;
        if(length(kernel)!=1) kernel <- "beta";
        res <- rvmeta.CMH.skat(X.T.times.Y.centered.list,X.T.times.X.list,maf.vec,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha,kernel);
      }
    ix.var <- 1:length(maf.vec);
    if(rv.test=='VT')
      {
        ##ix.var <- which(maf.vec<=res$maf.cutoff);
        ix.var <- which(mac.vec<=res$mac.cutoff);
      }
    ######################print(X.T.times.X);
    X.T.times.X <- X.T.times.X[ix.var,ix.var];
    w <- rep(1,length(X.T.times.Y));
    if(rv.test=='WSS')
      {
        if(extra.pars$weight=='MB')
          {
            q <- ((maf.vec)+1/(2*N))*(2*N)/(2*N+2);
            w <- 1/sqrt(N*q*(1-q));
          }
      }
    ################################print("ix.var");
    ################################print(ix.var);
    
    ######################print(c("maf.cutoff",res$maf.cutoff));
    ######################print(c("maf.vec",maf.vec));
    ############################print(ix.var);

    ############################print(maf.vec[ix.var]);
    ######################print(ix.var);
    ######################print(X.T.times.Y);
    ######################print(X.T.times.X);
    beta1.est <- sum((w[ix.var])*(X.T.times.Y[ix.var]))/as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var]));
    beta1.sd <- sqrt(1/as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var])));
    macf.vec <- 2*(maf.vec[ix.var])*(1-maf.vec[ix.var])+(maf.vec[ix.var])*(maf.vec[ix.var]);
    hsq.est <- beta1.est*beta1.est*as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var]));
    beta1.conf.lower <- beta1.est-1.96*beta1.sd;
    beta1.conf.upper <- beta1.est+1.96*beta1.sd;
    return(c(res,list(direction.meta.single.var=direction.meta.single.var,
                      direction.burden.by.study=direction.burden.by.study,
                      beta1.est=beta1.est,
                      beta1.sd=beta1.sd,
                      no.site=length(ix.var),
                      hsq.est=hsq.est,
                      beta1.conf.lower=beta1.conf.lower,
                      beta1.conf.upper=beta1.conf.upper)));
  }
