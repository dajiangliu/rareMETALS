find.gene <- function(variant.list,window.size)
  {
    data(refFlat.resource);
    res <- res.refFlat;
    gene <- res$gene;
    chr <- res$chr;
    pos.start <- res$pos.start;
    pos.end <- res$pos.end;
    ####################print(variant.list[1:10]);
    split.variant.list <- matrix(unlist(strsplit(variant.list,split=":")),ncol=2,byrow=TRUE);
    chr.variant.list <- as.numeric(split.variant.list[,1]);
    pos.variant.list <- as.numeric(split.variant.list[,2]);
    range.variant <- paste(paste(chr.variant.list,pos.variant.list,sep=":"),pos.variant.list,sep="-");
    range.variant <- paste(range.variant,collapse=",");
    if(length(unique(chr.variant.list))>1) stop("Variants are on multiple chromosomes");
    pos.window.start <- max(pos.variant.list-window.size);
    pos.window.end <- min(pos.variant.list+window.size);
    ix.gene <- which(chr==chr.variant.list[1] & pos.start>pos.window.start & pos.end<pos.window.end);
    ##if(length(ix.gene)==0) return(character(0));
    ##if(length(ix.gene)>0) return(gene[ix.gene]);
    gene.vec <- gene[ix.gene];
    ####################print(gene.vec);
    range.vec <- paste(paste(chr[ix.gene],pos.start[ix.gene],sep=":"),pos.end[ix.gene],sep="-");    
    range.vec <- paste(range.vec,range.variant,sep=",");
    return(list(gene.vec=gene.vec,
                range.vec=range.vec));
  }
