conditional.rareMETALS.single <- function(candidate.variant.vec,score.stat.file,cov.file,singlevar.result,maf.cutoff,no.boot=10000,alternative=c('two.sided','greater','less'),alpha=0.05,ix.gold=1,out.digits=4,window.size=1e6,callrate.cutoff=0,hwe.cutoff=0,gene.file="refFlat_hg19.txt.gz",topN=1)
  {
    #singlevar.result consists of 3 columns: chr, pos, and p-value;
    extra.pars <- list(alpha=alpha,ix.gold=ix.gold,out.digits=out.digits,window.size=window.size,QC.par=list(callrate.cutoff=callrate.cutoff,hwe.cutoff=hwe.cutoff));
    window.size <- extra.pars$window.size;
    if(length(window.size)==0) window.size <- 1e6;
    ##if(is.null(known.variant.vec))
    
    res.find <- find.topN.variant.single(candidate.variant.vec,window.size,singlevar.result,topN);
    raw.data.all <- list();
    known.variant.vec <- res.find$known.variant.collapsed.vec;
    p.value.known.variant.vec <- res.find$p.value.known.variant.vec;
    anno.candidate.variant.vec <- res.find$anno.candidate.variant.vec;
    anno.known.variant.vec <- res.find$anno.known.variant.vec;
    candidate.variant.tabix.vec.tmp <- res.find$candidate.variant.tabix.vec;
    
    raw.data.all <- list();
    res.list <- list();
    candidate.variant.tabix.vec <- get.tabix.range(candidate.variant.vec);
    ix.rm <- integer(0);
    res <- conditional.rareMETALS.basic(candidate.variant.tabix.vec,anno.candidate.variant.vec,score.stat.file,cov.file,known.variant.vec,"SINGLE",maf.cutoff=1,no.boot=0,alternative,alpha,ix.gold,out.digits,callrate.cutoff,hwe.cutoff,gene.file,p.value.known.variant.vec,anno.known.variant.vec);    
    return(res);
  }
