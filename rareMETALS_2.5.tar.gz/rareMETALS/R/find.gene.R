find.gene.chrpos <- function(candidate.gene)
  {
    ##this function will return the tabix range for the gene and 
    data(refFlat.resource);
    res <- res.refFlat;
    gene <- res$gene;
    chr <- res$chr;
    pos.start <- res$pos.start;
    pos.end <- res$pos.end;
    ix <- match(candidate.gene,gene);
    tabix <- paste(chr[ix],paste(pos.start[ix],pos.end[ix],sep="-"),sep=":");
    return(tabix);
  }

get.tabix.range <- function(variant.vec)
  {
    variant.list <- variant.vec;
    ##variant.list <- strsplit(variant.list,split=",");
    range.vec <- 0;
    variant.list.split <- matrix(unlist(strsplit(variant.list,split=":")),ncol=2,byrow=TRUE);
    variant.list.split[,2] <- paste(variant.list.split[,2],variant.list.split[,2],sep='-');
    range.vec <- paste(variant.list.split[,1],variant.list.split[,2],sep=':',collapse=',');
    
    return(range.vec); 
  }
get.gene.inWindow <- function(known.variant.vec,window.size=1e6)
  {
    data(refFlat.resource);
    res <- res.refFlat;
    gene <- res$gene;
    chr <- res$chr;
    pos.start <- res$pos.start;
    pos.end <- res$pos.end;
    variant.list.split <- matrix(unlist(strsplit(known.variant.vec,split=":")),ncol=2,byrow=TRUE);
    pos.variant.list <- as.integer(variant.list.split[,2]);
    chr.variant.list <- as.integer(variant.list.split[,1]);
    pos.window.start <- max(pos.variant.list-window.size);
    pos.window.end <- min(pos.variant.list+window.size);
    ix.gene <- which(chr==chr.variant.list[1] & pos.start>pos.window.start & pos.end<pos.window.end);
    gene.vec <- gene[ix.gene];
    return(gene.vec);
  }


## find.gene <- function(variant.list,window.size,singlevar.result)
##   {
##     data(refFlat.resource);
##     res <- res.refFlat;
##     gene <- res$gene;
##     chr <- res$chr;
##     pos.start <- res$pos.start;
##     pos.end <- res$pos.end;
##     split.variant.list <- matrix(unlist(strsplit(variant.list,split=":")),ncol=2,byrow=TRUE);
##     chr.variant.list <- as.numeric(split.variant.list[,1]);
##     pos.variant.list <- as.numeric(split.variant.list[,2]);

##     chr.pos.singlevar <- paste(singlevar.result[,1:2],sep=":");
##     ix.known.variant <- match(variant.list,chr.pos.single.var);
##     p.value.known.variant <- singlevar.result[ix.known.variant,3];
##     range.variant <- paste(paste(chr.variant.list,pos.variant.list,sep=":"),pos.variant.list,sep="-");
##     range.variant <- paste(range.variant,collapse=",");
##     if(length(unique(chr.variant.list))>1) stop("Variants are on multiple chromosomes");
##     pos.window.start <- max(pos.variant.list-window.size);
##     pos.window.end <- min(pos.variant.list+window.size);
##     ix.gene <- which(chr==chr.variant.list[1] & pos.start>pos.window.start & pos.end<pos.window.end);
##     gene.vec <- gene[ix.gene];
##     candidate.variant.tabix.vec <- paste(paste(chr[ix.gene],pos.start[ix.gene],sep=":"),pos.end[ix.gene],sep="-");
##     all.variant.tabix.vec <- paste(all.variant.tabix.vec,get.tabix.range(variant.list),sep=',');
##     return(list(gene.vec=gene.vec,
##                 p.value.known.variant=p.value.known.variant,
##                 candidate.variant.tabix.vec=candidate.variant.tabix.vec,
##                 all.variant.tabix.vec=all.variant.tabix.vec));
##   }


## find.topN.variant.single <- function(candidate.variant.vec,window.size,singlevar.result,topN=1,out.digits=4)
##   {
##     chr.pos.tmp <- matrix(unlist(strsplit(candidate.variant.vec,split=":")),byrow=TRUE,ncol=2);
##     chr.variant <- as.numeric(chr.pos.tmp[,1]);
##     pos.variant <- as.numeric(chr.pos.tmp[,2]);
##     singlevar.result[,1] <- as.numeric(singlevar.result[,1]);
##     singlevar.result[,2] <- as.numeric(singlevar.result[,2]);
    
##     p.value.vec <- 0;known.variant.collapsed.vec <- 0;candidate.variant.tabix.vec <- 0;anno.known.variant.vec <- 0;anno.candidate.variant.vec <- 0;ix.rm <- integer(0);
##     for(ii in 1:length(candidate.variant.vec))
##       {
##         pos.start.window <- max(pos.variant[ii]-window.size,1);
##         pos.end.window <- pos.variant[ii]+window.size;
##         ####################print(c(chr.variant[ii],pos.variant[ii]));
##         ix.candidate <- which(singlevar.result[,1]==chr.variant[ii] & singlevar.result[,2]==pos.variant[ii]);
##         ix.var <- which(singlevar.result[,1]==chr.variant[ii] & singlevar.result[,2]>=pos.start.window & singlevar.result[,2]<=pos.end.window);
##         if(length(ix.var)==0) ix.rm <- c(ix.rm,ii)
##         if(length(ix.var)>0){
##           p.value.tmp <- singlevar.result[ix.var,3];
##           topN <- min(topN,length(ix.var));
##           ix.min <- ix.var[order(which.min(p.value.tmp))[1:topN]];
##           anno.candidate.variant.vec[ii] <- singlevar.result[ix.candidate,4];
##           known.variant.collapsed.vec[ii] <- paste(singlevar.result[ix.min,1],singlevar.result[ix.min,2],sep=":",collapse=",");
##           candidate.variant.tabix.vec[ii] <- get.tabix.range(candidate.variant.vec[ii]);
##           p.value.vec[ii] <- paste(format(singlevar.result[ix.min,3],digits=out.digits),collapse=",");
##           anno.known.variant.vec[ii] <- paste(singlevar.result[ix.min,4],collapse=",",sep=",");
##         }
##       }
##     if(length(ix.rm)>0) {
##       known.variant.collapsed.vec <- known.variant.collapsed.vec[-ix.rm];
##       candidate.variant.tabix.vec <- candidate.variant.tabix.vec[-ix.rm];
##       anno.known.variant.vec <- anno.known.variant.vec[-ix.rm];
##       anno.candidate.variant.vec <- anno.candidate.variant.vec[-ix.rm];
##       p.value.vec <- p.value.vec[-ix.rm];
##     }
##     return(list(known.variant.collapsed.vec=known.variant.collapsed.vec,
##                 candidate.variant.tabix.vec=candidate.variant.tabix.vec,
##                 anno.known.variant.vec=anno.known.variant.vec,
##                 anno.candidate.variant.vec=anno.candidate.variant.vec,
##                 p.value.known.variant.vec=p.value.vec));
##   }

## find.topN.variant <- function(gene.name,window.size,singlevar.result,topN=1,out.digits=4)
##   {
##     data(refFlat.resource);
##     res <- res.refFlat;
##     gene <- res$gene;
##     chr <- res$chr;
##     pos.start <- res$pos.start;
##     pos.end <- res$pos.end;
##     ix.gene <- match(gene.name,gene);
##     chr.gene <- chr[ix.gene];
##     pos.start.gene <- pos.start[ix.gene];
##     pos.end.gene <- pos.end[ix.gene];
##     known.variant.collapsed.vec <- 0;
##     candidate.variant.tabix.vec <- 0;
##     anno.known.variant.vec <- 0;
##     p.value.vec <- 0;
##     ix.rm <- integer(0);
##     for(ii in 1:length(ix.gene))
##       {
##         pos.start.window <- max(pos.start.gene[ii]-window.size,1);
##         pos.end.window <- pos.end.gene[ii]+window.size;
##         ix.var <- which(singlevar.result[,1]==chr.gene[ii] & singlevar.result[,2]>=pos.start.window & singlevar.result[,2]<=pos.end.window);
##         ########################print(c(ii,gene.name[ii],length(ix.var),ix.var));
##         if(length(ix.var)==0) ix.rm <- c(ix.rm,ii)
##         if(length(ix.var)>0){
##           p.value.tmp <- singlevar.result[ix.var,3];
##           topN <- min(topN,length(ix.var));
##           ix.min <- ix.var[order(which.min(p.value.tmp))[1:topN]];
##           ######################print(c(ix.var,ix.min));
##           known.variant.collapsed.vec[ii] <- paste(singlevar.result[ix.min,1],singlevar.result[ix.min,2],sep=":",collapse=",");
##           anno.known.variant.vec[ii] <- paste(anno.known.variant.vec[ix.min,4],sep=",",collapse=",");
##           candidate.variant.tabix.vec[ii] <- paste(chr.gene[ii],paste(pos.start.gene[ii],pos.end.gene[ii],sep="-"),sep=":");
##           p.value.vec[ii] <- paste(format(singlevar.result[ix.min,3],digits=out.digits),collapse=",");
##         }
##       }
##     if(length(ix.rm)>0) {
##       known.variant.collapsed.vec <- known.variant.collapsed.vec[-ix.rm];
##       candidate.variant.tabix.vec <- candidate.variant.tabix.vec[-ix.rm];
##       anno.known.variant.vec <- anno.known.variant.vec[-ix.rm];
##       gene.name <- gene.name[-ix.rm];
##       p.value.vec <- p.value.vec[-ix.rm];
##     }    
##     return(list(known.variant.collapsed.vec=known.variant.collapsed.vec,
##                 gene.name=gene.name,
##                 anno.known.variant.vec=anno.known.variant.vec,
##                 candidate.variant.tabix.vec=candidate.variant.tabix.vec,
##                 p.value.known.variant.vec=p.value.vec));
    
##   }
