##rareMETALS.single <- function(score.stat.file,cov.file,range,alternative=c('two.sided','greater','less'),extra.par=list(ix.gold=1,QC.par=list(callrate.cutoff=0,hwe.cutoff=0)))
rareMETALS.single <- function(score.stat.file,cov.file,range,alternative=c('two.sided','greater','less'),ix.gold=1,callrate.cutoff=0,hwe.cutoff=0)
  {
    extra.par <- list(ix.gold=ix.gold,QC.par=list(callrate.cutoff=callrate.cutoff,hwe.cutoff=hwe.cutoff));
    capture.output(raw.data.all <- rvmeta.readDataByRange( score.stat.file, cov.file, range));
    if(length(raw.data.all)==0)
      return(list(list(p.value=NA,
                       skip=1,
                       statistic=NA,
                       no.var=0,
                       no.sample=NA)));
    if(length(alternative)>1) alternative <- alternative[1];
    ix.gold <- extra.par$ix.gold;
    if(length(extra.par$ix.gold)==0) ix.gold <- 1;
    raw.data <- raw.data.all[[1]];
    if(length(extra.par$QC.par)>0) 
      raw.data <- QC(raw.data,extra.par$QC.par,cov=0);        
    ix.pop <- 1:length(raw.data$ref);
    ref.gold <- raw.data$ref[[ix.gold]];
    alt.gold <- raw.data$alt[[ix.gold]];
    U.stat <- 0;V.stat.sq <- 0;V.stat.sq <- 0;
    p.value <- 0;statistic <- 0;
    direction.by.study <- "+";
    beta1.est <- 0;
    beta1.sd <- 0;
    hsq.est <- 0;
    no.sample <- 0;
    maf.vec <- 0;
    no.sample.pop <- 0;
    no.sample.var <- 0;
    ##########print(length(raw.data$nSample[[1]]));
    no.sample.mat <- matrix(nrow=length(ix.pop),ncol=length(raw.data$nSample[[1]]));
    for(ii in 1:length(ix.pop))
      {
        ##########print(ii);
        no.sample.mat[ii,] <- (raw.data$nref[[ii]])+(raw.data$nalt[[ii]])+(raw.data$nhet[[ii]]);

        ix.na <- which(is.na(no.sample.mat[ii,]));
        if(length(ix.na)>0)
          {
            no.sample.mat[ii,ix.na] <- rm.na(mean(raw.data$nSample[[ii]],na.rm=TRUE));## replace no count with 0;
          }                       
        raw.data$ustat[[ii]] <- rm.na(raw.data$ustat[[ii]]);
        raw.data$vstat[[ii]] <- rm.na(raw.data$vstat[[ii]]);
        raw.data$af[[ii]] <- rm.na(raw.data$af[[ii]]);
      }
    ##########print('okay');
    ix.var <- 1;
    for(ix.var in 1:length(raw.data$ref[[ix.gold]]))
      {
        ##########print(ix.var);
        direction.by.study.var <- rep("?",length(ix.pop));
        U.stat <- 0;V.stat.sq <- 0;maf.pop <- 0;
        for(ii in 1:length(ix.pop))
          {
            if(is.na(ref.gold[ix.var]) & !is.na(raw.data$ref[[ii]][ix.var]))
              {
                ref.gold[ix.var] <- raw.data$ref[[ii]][ix.var];
                alt.gold[ix.var] <- raw.data$alt[[ii]][ix.var];
              }

            if((is.na(alt.gold[ix.var]) | alt.gold[ix.var]=='0'| alt.gold[ix.var]=='.')  & (!is.na(raw.data$alt[[ii]][ix.var]) & raw.data$alt[[ii]][ix.var]!="0" & raw.data$alt[[ii]][ix.var]!="." ))
              {
                alt.gold[ix.var] <- raw.data$alt[[ii]][ix.var];
              }
            if(!is.na(ref.gold[ix.var]) & !is.na(raw.data$ref[[ii]][ix.var]) )
              {
                if(ref.gold[ix.var]==(raw.data$ref[[ii]][ix.var]) & alt.gold[ix.var]==(raw.data$alt[[ii]][ix.var]))
                  {
                    U.stat <- U.stat+(raw.data$ustat[[ii]][ix.var]);
                    V.stat.sq <- V.stat.sq+((raw.data$vstat[[ii]][ix.var]))^2;
                  }
                if(alt.gold[ix.var]==(raw.data$ref[[ii]][ix.var]) & ref.gold[ix.var]==(raw.data$alt[[ii]][ix.var]))
                  {
                    raw.data$af[[ii]][ix.var] <- 1-raw.data$af[[ii]][ix.var];
                    raw.data$ustat[[ii]][ix.var] <- (-1)*(raw.data$ustat[[ii]][ix.var]);
                    U.stat <- U.stat+(raw.data$ustat[[ii]][ix.var]);
                    V.stat.sq <- V.stat.sq+(raw.data$vstat[[ii]][ix.var])^2;
                    
                  }
                if(raw.data$ustat[[ii]][ix.var]>0) direction.by.study.var[ii] <- "+";
                if(raw.data$ustat[[ii]][ix.var]<0) direction.by.study.var[ii] <- "-";
                if(raw.data$ustat[[ii]][ix.var]==0) direction.by.study.var[ii] <- "?";
              }

            maf.pop[ii] <- rm.na((raw.data$af[[ii]])[ix.var]);

            if(maf.pop[ii]==1) maf.pop[ii] <- 0;
            ##########print('okay here');
            ##########print(maf.pop[ii]);
          }
        maf.vec[ix.var] <- sum(maf.pop*no.sample.mat[,ix.var])/sum(no.sample.mat[,ix.var]);
        direction.by.study[ix.var] <- paste(direction.by.study.var,sep='',collapse='');
        beta1.est[ix.var] <- U.stat/V.stat.sq;
        
        beta1.sd[ix.var] <- sqrt(1/V.stat.sq);
        hsq.est[ix.var] <- (beta1.est[ix.var])*(beta1.est[ix.var])*V.stat.sq/sum(no.sample.mat[,ix.var]);
        no.sample.var[ix.var] <- sum(no.sample.mat[,ix.var]);
        ## ######################################################print(c(raw.data$pos[ix.var],beta1.est[ix.var],V.stat.sq,maf.vec[ix.var]));
        ## if(raw.data$pos[ix.var]=="1:1164015")
        ##   {
        ##     ######################################################print(c(maf.vec[ix.var],U.stat,V.stat.sq));
        ##     for(ii in 1:length(ix.pop))
        ##       {
        ##         ######################################################print(c(raw.data$ustat[[ii]][ix.var],raw.data$vstat[[ii]][ix.var],raw.data$af[[ii]][ix.var]));
        ##       }
        ##     stop("1:1164015");
        ##   }
        ######################################################print(c(U.stat,V.stat.sq));
        if(alternative=='two.sided'){
          statistic[ix.var] <- U.stat^2/V.stat.sq;
          p.value[ix.var] <- pchisq(statistic[ix.var],df=1,lower.tail=FALSE)
        }
        if(alternative=='greater'){
          statistic[ix.var] <- (U.stat/sqrt(V.stat.sq));
          p.value[ix.var] <- pnorm(statistic[ix.var],lower.tail=FALSE)
        }
        if(alternative=='less'){
          statistic[ix.var] <- (U.stat/sqrt(V.stat.sq));
          p.value[ix.var] <- pnorm(statistic[ix.var],lower.tail=TRUE)
        }
      }
    return(list(p.value=p.value,
                ref=ref.gold,
                alt=alt.gold,
                raw.data=raw.data,
                statistic=statistic,
                direction.by.study=direction.by.study,
                anno=raw.data$anno,
                maf=maf.vec,
                no.sample=no.sample.var,
                beta1.est=beta1.est,
                beta1.sd=beta1.sd,
                hsq.est=hsq.est,
                pos=raw.data$pos));
  }
