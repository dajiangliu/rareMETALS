QC <- function(raw.data,QC.par,cov=1)
  {
    
    hwe.cutoff <- QC.par$hwe.cutoff;
    callrate.cutoff <- QC.par$callrate.cutoff;
    if(length(hwe.cutoff)==0) hwe.cutoff <- 0;
    if(length(callrate.cutoff)==0) callrate.cutoff <- 0;
    for(ii in 1:length(raw.data$hwe))
      {
        hwe.ii <- raw.data$hwe[[ii]];
        callrate.ii <- raw.data$callrate[[ii]];
        ix.rm <- which(callrate.ii<callrate.cutoff | hwe.ii<hwe.cutoff);
        ix.rm <- unique(ix.rm);
        if(length(ix.rm)>0)
          {
            ######################################################print(c("SNP QCed",ix.rm));
            raw.data$ustat[[ii]][ix.rm] <- NA;

            raw.data$vstat[[ii]][ix.rm] <- NA;
            if(cov==1)
              {
                raw.data$cov[[ii]][ix.rm,ix.rm] <- NA;
              }
            raw.data$ref[[ii]][ix.rm] <- NA;
            raw.data$alt[[ii]][ix.rm] <- NA;
            raw.data$nSample[[ii]][ix.rm] <- NA;
            raw.data$af[[ii]][ix.rm] <- NA;
            raw.data$ac[[ii]][ix.rm] <- NA;
            raw.data$nref[[ii]][ix.rm] <- NA;
            raw.data$nhet[[ii]][ix.rm] <- NA;
            raw.data$nalt[[ii]][ix.rm] <- NA;
            raw.data$effect[[ii]][ix.rm] <- NA;
            raw.data$pVal[[ii]][ix.rm] <- NA; 
          }
      }
    return(raw.data);
  }
