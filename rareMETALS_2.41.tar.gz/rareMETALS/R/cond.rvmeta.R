cond.rvmeta <- function(score.stat.vec.list,maf.vec.list,cov.mat.list,var.Y.list,N.list,alternative=c('two.sided','greater','less'),no.boot,alpha=0.05,rv.test,extra.pars=list())
  {
    if(length(alternative)>1) alternative <- "two.sided";
    res.list <- list();
    ix.X1 <- extra.pars$ix.X1;
    ix.X2 <- extra.pars$ix.X2
    X.T.times.Y.centered.list <- list();
    X.T.times.X.list <- list();
    X.T.times.Y.centered.uncond.list <- list();
    X.T.times.X.uncond.list <- list();

    maf.vec <- rep(0,length(ix.X1));
    mac.vec <- maf.vec;
    mac.vec.list <- extra.pars$mac.vec.list;
    X.T.times.Y <- rep(0,length(ix.X1));
    X.T.times.X <- matrix(0,nrow=length(ix.X1),ncol=length(ix.X1));
    direction.burden.by.study.vec <- rep('',length(score.stat.vec.list));
    direction.meta.single.var.vec <- rep('',length(ix.X1));
    maf.vec.cond.list <- list();
    mac.vec.cond.list <- list();
    direction.code <- c('-','?',"+");
    direction.single.mat <- matrix(nrow=length(score.stat.vec.list),ncol=length(ix.X1))
    for(ii in 1:length(score.stat.vec.list))
      {
        score.stat.vec.list[[ii]] <- rm.na(score.stat.vec.list[[ii]]);
        U.ii <- sum(score.stat.vec.list[[ii]]);
        maf.vec.list[[ii]] <- rm.na(maf.vec.list[[ii]]);
        mac.vec.list[[ii]] <- rm.na(mac.vec.list[[ii]]);
        maf.vec.cond.list[[ii]] <- maf.vec.list[[ii]][ix.X1];
        mac.vec.cond.list[[ii]] <- mac.vec.list[[ii]][ix.X1];
        cov.mat.list[[ii]] <- as.matrix(rm.na(cov.mat.list[[ii]]));
        var.Y.list[[ii]] <- 1;
        X.T.times.X.uncond.list[[ii]] <- N.list[[ii]]*(cov.mat.list[[ii]])*(var.Y.list[[ii]]);
        
        X.T.times.Y.centered.uncond.list[[ii]] <- (sqrt(N.list[[ii]]))*(score.stat.vec.list[[ii]])*sqrt(diag(cov.mat.list[[ii]]))*sqrt(var.Y.list[[ii]]);
        maf.vec <- maf.vec.list[[ii]][ix.X1]*(N.list[[ii]])+maf.vec
        mac.vec <- mac.vec.list[[ii]][ix.X1]+mac.vec;
        res.cond.ii <- cond.rvmeta.core(X.T.times.Y.centered.uncond.list[[ii]],X.T.times.X.uncond.list[[ii]],extra.pars$maf.vec,N.list[[ii]],var.Y.list[[ii]],ix.X1,ix.X2,"generic",alternative,no.boot,list());
        X.T.times.Y.centered.list[[ii]] <- rm.na(as.vector(res.cond.ii$X.T.times.Y));
        direction.single.mat[ii,] <- direction.code[sign(X.T.times.Y.centered.list[[ii]])+2];
        X.T.times.X.list[[ii]] <- rm.na(res.cond.ii$X.T.times.X);

        cov.mat.list[[ii]] <- rm.na(X.T.times.X.list[[ii]]/N.list[[ii]]);
        if(U.ii>0) direction.burden.by.study.vec[ii] <- "+";
        if(U.ii<0) direction.burden.by.study.vec[ii] <- "-";
        if(U.ii==0) direction.burden.by.study.vec[ii] <- "?";                
        X.T.times.Y <- X.T.times.Y+X.T.times.Y.centered.list[[ii]];

        X.T.times.X <- X.T.times.X+X.T.times.X.list[[ii]];
      }
    direction.single.vec <- apply(direction.single.mat,2,paste,sep='',collapse='');
    maf.vec.cond <- (extra.pars$maf.vec)[ix.X1];
    mac.vec.cond <- mac.vec[ix.X1];
    for(ii in 1:length(ix.X1))
      {
        U.ii <- X.T.times.Y[ii];
        if(U.ii>0) direction.meta.single.var.vec[ii] <- "+";
        if(U.ii<0) direction.meta.single.var.vec[ii] <- "-";
        if(U.ii==0) direction.meta.single.var.vec[ii] <- "?"; 
      }
    direction.meta.single.var <- paste(direction.meta.single.var.vec,sep='',collapse='');
    direction.burden.by.study <- paste(direction.burden.by.study.vec,sep='',collapse='');
    N <- sum(unlist(N.list));
    maf.vec <- maf.vec/N;
    cov.mat <- X.T.times.X/N;
    
    if(length(X.T.times.Y)==1)
      {
        U.stat <- X.T.times.Y;
        V.stat.sq <- as.numeric(X.T.times.X);
        var.X <- cov.mat;
        beta1.est <- U.stat/V.stat.sq;
        beta1.sd <- 1/V.stat.sq;
        hsq.est <- beta1.est*beta1.est*var.X;        
        if(alternative=='two.sided')
          {
            statistic <- U.stat^2/V.stat.sq;
            p.value <- pchisq(statistic,df=1,lower.tail=FALSE);
          }
        if(alternative=='greater')
          {
            statistic <- U.stat/sqrt(V.stat.sq);
            p.value <- pnorm(statistic,lower.taill=FALSE);
          }
        if(alternative=='less')
          {
            statistic <- U.stat/sqrt(V.stat.sq);
            p.value <- pnorm(statistic,lower.taill=TRUE);
          }
        return(list(statistic=statistic,
                    p.value=p.value,
                    p.value.single=p.value,
                    no.site=1,
                    beta1.est=beta1.est,
                    beta1.sd=beta1.sd,
                    beta1.est.single=beta1.est,
                    beta1.sd.single=beta1.sd,
                    hsq.est=hsq.est,
                    maf.vec=maf.vec,
                    direction.single.vec=direction.single.vec,
                    direction.meta.single.var=direction.meta.single.var,
                    direction.burden.by.study=direction.burden.by.study));
      }
    
    U.stat <- X.T.times.Y;
    V.stat.sq <- as.numeric(diag(X.T.times.X));
    if(alternative=='two.sided')
      {
        statistic.single <- U.stat^2/V.stat.sq;
        p.value.single <- pchisq(statistic.single,df=1,lower.tail=FALSE);
      }
    if(alternative=='greater')
      {
        statistic.single <- U.stat/sqrt(V.stat.sq);
        p.value.single <- pnorm(statistic.single,lower.taill=FALSE);
      }
    if(alternative=='less')
      {
        statistic.single <- U.stat/sqrt(V.stat.sq);
        p.value.single <- pnorm(statistic,lower.taill=TRUE);
      }
    beta1.est.single <- U.stat/V.stat.sq;
    beta1.sd.single <- 1/V.stat.sq;
    
    if(rv.test=='WSS')
      {
        weight <- extra.pars$weight;
        if(length(weight)!=1) weight <- 'MB';
        ##############print(maf.vec.cond);
        res <- rvmeta.CMH.wss(X.T.times.Y.centered.list,X.T.times.X.list,maf.vec.cond,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha,weight);
      }

    if(rv.test=='VT')
      {
        res <- rvmeta.CMH.vt(X.T.times.Y.centered.list,X.T.times.X.list,mac.vec.cond,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha);
      }

    if(rv.test=='SKAT')
      {
        kernel <- extra.pars$kernel;
        if(length(kernel)!=1) kernel <- "beta";
        res <- rvmeta.CMH.skat(X.T.times.Y.centered.list,X.T.times.X.list,maf.vec.cond,cov.mat.list,var.Y.list,N.list,alternative,no.boot,alpha,kernel);
      }
    ix.var <- 1:length(maf.vec);

    if(rv.test=='VT')
      {
        ix.var <- which(mac.vec<=res$mac.cutoff);
      }
    
    X.T.times.X <- X.T.times.X[ix.var,ix.var];
    w <- rep(1,length(X.T.times.Y));
    if(rv.test=='WSS')
      {
        if(extra.pars$weight=='MB')
          {
            q <- ((maf.vec)+1/(2*N))*(2*N)/(2*N+2);
            w <- 1/sqrt(N*q*(1-q));
          }
      }
    beta1.est <- sum((w[ix.var])*(X.T.times.Y[ix.var]))/as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var]));
    beta1.sd <- sqrt(1/as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var])));
    macf.vec <- 2*(maf.vec[ix.var])*(1-maf.vec[ix.var])+(maf.vec[ix.var])*(maf.vec[ix.var]);
    hsq.est <- beta1.est*beta1.est*as.numeric(t(w[ix.var])%*%X.T.times.X%*%(w[ix.var]));
    beta1.conf.lower <- beta1.est-1.96*beta1.sd;
    beta1.conf.upper <- beta1.est+1.96*beta1.sd;
    return(c(res,list(direction.meta.single.var=direction.meta.single.var,
                      direction.burden.by.study=direction.burden.by.study,
                      direction.single.vec=direction.single.vec,
                      beta1.est=beta1.est,
                      beta1.sd=beta1.sd,
                      beta1.est.single=beta1.est.single,
                      beta1.sd.single=beta1.sd.single,
                      no.site=length(ix.var),
                      hsq.est=hsq.est,
                      maf.vec=maf.vec,
                      p.value.single=p.value.single,
                      statistic.single=statistic.single,
                      beta1.conf.lower=beta1.conf.lower,
                      beta1.conf.upper=beta1.conf.upper)));
  }
